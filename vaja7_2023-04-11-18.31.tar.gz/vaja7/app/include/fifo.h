#ifndef FIFO_H_INCLUDED
#define FIFO_H_INCLUDED
#include <stdint.h>

typedef struct{
    uint8_t read_idx;//256 bytou
    uint8_t write_idx;
    uint8_t size;
    uint8_t *data;//pointer
}fifo_t;


uint8_t fifo_write(fifo_t *fifo, const uint8_t *data, uint8_t n);//*fifo naslov kje v pomnilniku se nahaja//n kolko bytou hocem upisat
//return ce je use uredu -> returnam kolko bytou sem zapisau

uint8_t fifo_read(fifo_t *fifo, uint8_t *data, uint8_t n);//iz kje beremo, kam zapise, kolko preberemo(bytes)
//return
void test_fifo(void);
uint8_t fifo_peek(fifo_t *fifo, char *data, uint8_t n);

#endif // FIFO_H_INCLUDED
