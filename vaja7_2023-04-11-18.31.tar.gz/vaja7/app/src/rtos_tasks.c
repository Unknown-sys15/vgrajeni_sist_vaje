#include <rtos_tasks.h>
#include <test_board.h>
extern int sek,min;

uint8_t keys_buff[KEYS_FIFO_SIZE];
fifo_t keys_fifo = {0,0,KEYS_FIFO_SIZE,keys_buff};


/********************************/
rtos_task_t task_blink = {
    .name = "blink",
    .last_tick = 0,
    .task_function = blink_driver
};

void blink_driver(void){
    static uint32_t count=0;
    count++;
    //blinkaj na 1s
    if(count == 20){
        count=0;
        ioport_toggle_pin_level(D1);
    }
}
/********************************/
rtos_task_t task_lcd={
    .name = "lcd",
    .task_function = lcd_driver
};

/********************************/
rtos_task_t task_txt={
    .name = "txt",
    .last_tick = 0,
    .task_function = txt_driver
};

void txt_driver(void){
    ///uint8_t fifo_current [10] = {' ',' ',' ',' ',' ',' ',' ',' ',' ',' '};
    uint8_t n,i;
    n = fifo_peek(&keys_fifo, lcd_string, keys_fifo.size);//po keys fifo zapisi presledke
    for(i=n;i<keys_fifo.size;i++){
        lcd_string[i]=' ';
    }
}
/********************************/
rtos_task_t task_led={
    .name = "led",
    .last_tick = 0,
    .task_function = led_driver
};

void led_driver(void){

    uint8_t c;
    static uint32_t count=0;
    static uint32_t toBlink=0;
    static bool finished = true, wait=false;


    if((keys_fifo.read_idx != keys_fifo.write_idx) && finished && !wait){
        fifo_read(&keys_fifo, &c, 1);
        toBlink = c-48;
        finished = false;
        wait=true;
        count = 0;
    }
    if((count == toBlink*10) && !finished){
        finished=true;
    }

    if(count%10 == 0 && !finished){//izvede na 10 20 30 ...
        ioport_toggle_pin_level(D2);
    }

    if(count%10 == 4 && !finished){//izvede na 14 24 34 ...
        ioport_toggle_pin_level(D2);
    }



    //wait
    if((count == toBlink*10+100) && wait){//pauza 1s
        count = 0;
        wait=false;
    }

    count++;

}
/********************************/
rtos_task_t task_btn={
    .name = "btn",
    .last_tick = 0,
    .task_function = btn_driver
};

void btn_driver(void){
    uint32_t button_state = get_button_press();
    uint8_t n;

    if(button_state & 0x01){
            //uint32_t n;
            //uint8_t c_beri, c_pisi=’1’;
            //n = fifo_write(&keys_fifo, &c_pisi, 1); // n=1 če je vse ok, v FIFO se zapiše ‘1’

            n = fifo_write(&keys_fifo, (uint8_t *)"1", 1); // n=1 če je vse ok, v c_beri se zapiše ‘1’
            //n = fifo_write(&keys_fifo, “hello”, 5);

    }
    if(button_state & 0x02){
            n = fifo_write(&keys_fifo, (uint8_t *)"2", 1);
    }
    if(button_state & 0x04){
            n = fifo_write(&keys_fifo, (uint8_t *)"3", 1);
    }
    if(button_state & 0x08){
            n = fifo_write(&keys_fifo, (uint8_t *)"4", 1);
    }
}
/********************************/
rtos_task_t task_dummy={
    .name = "dummy",
    .last_tick = 0,
    .task_function = dummy_driver
};

void dummy_driver(void){
    ;//nedela nic samo timing
}
/********************************/
rtos_task_t *rtos_task_list[]={&task_blink,&task_lcd,&task_btn,&task_txt,&task_dummy,0};//
rtos_task_t *priv_task = &task_led;
