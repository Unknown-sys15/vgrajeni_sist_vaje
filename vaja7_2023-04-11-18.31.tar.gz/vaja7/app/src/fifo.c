#include "fifo.h"

uint8_t fifo_read(fifo_t *fifo, uint8_t *data, uint8_t n){
    /**
        vhod:   fifo:naslov
                data:naslov podatkov
                n:st. bytou za pisanje
        Vrne: št. uspešno zapisanih
    **/
    uint8_t i = 0;
    for(i=0; i<n; i++){

        if(fifo->read_idx != fifo->write_idx){
            data[i] = fifo->data[fifo->read_idx];//beri podatek
            fifo->data[fifo->read_idx] = 'P'; //ni potrebno
        }
        else{
            return i;//fifo prazen
        }
        fifo->read_idx = fifo->read_idx+1;//-> acces struct data
        if(fifo->read_idx >= fifo->size){
            fifo->read_idx = 0;//postavi ga na zacetek
        }
    }

    return i;
}

uint8_t fifo_write(fifo_t *fifo, const uint8_t *data, uint8_t n){
    /**
        vhod:   fifo:naslov
                data:naslov podatkov
                n:st. bytou za pisanje
        Vrne: št. uspešno zapisanih
    **/
    uint8_t i = 0;
    uint8_t write_new;

    for(i=0; i<n; i++){
        write_new = fifo->write_idx +1;
        if(write_new >= fifo->size){
            write_new = 0;
        }
        if(write_new != fifo->size){
            fifo->data[fifo->write_idx] = data[i];
        }
        else{
            return i;
        }
        fifo->write_idx = write_new;//-> acces struct data
    }
    return i;
}

#define TEST_SIZE 7
void test_fifo(void){
    uint8_t test_buff[TEST_SIZE]={0};
    fifo_t test_fifo = {
        .size = TEST_SIZE,
        .read_idx = 0,
        .write_idx = 0,
        .data = test_buff
    };
    uint8_t n;
    n = fifo_write(&test_fifo, (uint8_t *)"abcd",4);

    //branje 3
    uint8_t read[10] = {0};
    n = fifo_read( &test_fifo, read, 3);

    //pisanje 1,2
    uint8_t d[2]={1,2};
    n=fifo_write(&test_fifo,d,2);

    n = fifo_read(&test_fifo, read, 3);

    n = fifo_write(&test_fifo, (uint8_t *)"ABCDEF",6);
}

//nevem ce dela
uint8_t fifo_peek(fifo_t *fifo, char *data, uint8_t n){
    /**
        vhod:   fifo:naslov
                data:naslov podatkov
                n:st. bytou za pisanje
        Vrne: št. uspešno zapisanih
    **/
    uint8_t i = 0;
    uint8_t peekTrack = fifo->read_idx;
    for(i=0; i<n; i++){

        if(fifo->read_idx != fifo->write_idx){
            data[i] = fifo->data[fifo->read_idx];//beri podatek
        }
        else{
            fifo->read_idx = peekTrack;
            return i;//fifo prazen
        }
        fifo->read_idx = fifo->read_idx+1;//-> acces struct data
        if(fifo->read_idx >= fifo->size){
            fifo->read_idx = 0;//postavi ga na zacetek
        }
    }
    fifo->read_idx = peekTrack;

    return i;
}
