#include <asf.h>
#include <delay.h>
#include <ioport.h>
#include <string.h>
#include "test_board.h"
#include "lcd.h"
#include <tc.h>
#include <rtos.h>
#include <rtos_tasks.h>
#include <fifo.h>
#include <math.h>


#ifdef __cplusplus
extern "C" {
#endif

void timer1_init(void);
uint32_t pos = 0;
char spaces[17]="                  ";
int esc_flag = 0;

void UART_Handler(void){
    if(!esc_flag){
        if(pos < 32){
            while(!uart_read(UART, lcd_string + pos));
            pos++;
        }
        else if(pos >= 32){
            pos = 16;
            memcpy(lcd_string, lcd_string + 16, 16);
            memcpy(lcd_string + 16, spaces, 16);
            while(!uart_read(UART, lcd_string + pos));
            pos++;

        }
    }
    else if(esc_flag){
        char read_tmp;
        while(!uart_read(UART, &read_tmp));
        while(uart_write(UART, read_tmp) != 0);
        if(read_tmp == 27){
            esc_flag = 0;
        }
    }

}

int main (void)
{
    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/
    /****INIT UART****/
    sysclk_enable_peripheral_clock(ID_PIOA);
    sam_uart_opt_t uart_opts = {
        .ul_mck = SystemCoreClock,
        // master clock
        .ul_baudrate = 9600,
        // hitrost prenosa
        .ul_mode = UART_MR_CHMODE_NORMAL | UART_MR_PAR_NO
        // glej datasheet
    };

    pio_set_peripheral(PIOA, PIO_PERIPH_A, PIO_PA8A_URXD | PIO_PA9A_UTXD);
    pio_pull_up(PIOA, PIO_PA8A_URXD | PIO_PA9A_UTXD, PIO_PULLUP);
    NVIC_EnableIRQ(UART_IRQn); //pogledas v sam3x8e.h
    sysclk_enable_peripheral_clock(ID_UART);
    uart_init(UART, &uart_opts);

    init_button_led();
    delay_init();

    lcd_init();
    uart_enable_interrupt(UART, UART_IER_RXRDY);
    uart_enable(UART);


    /********************* Main loop     ***************************/
    while(uart_write(UART, 'd') != 0);

    while(1)
    {
        for(uint8_t i = 0; i < 32; i++){
        if(lcd_string[i] == 27){
            esc_flag = 1;
            lcd_string[i] = '0';
        }
    }

        lcd_driver();
        //čekiraj esc btn



    }

    /*********************** varnost ***************************/
    while(1)
    {

    }


}


#ifdef __cplusplus
}
#endif
