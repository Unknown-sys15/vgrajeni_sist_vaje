#include <asf.h>
#include <delay.h>
#include <ioport.h>
#include <lcd.h>

#ifdef __cplusplus
extern "C" {
#endif
#include "test_board.h"



//#define L_PORT PIOB
//#define L_PIN_MSK 1<<27     //PIO_PB28      0xvrednost tudi okej
//#define RX_PORT PIOC
//#define RX_PIN_MSK 1<<30
//#define TX_PORT PIOA
//#define TX_PIN_MSK 1<<21



void cakaj(int n);//prototip oz deklaracija funkcij

int main (void)
{

    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();

    //IOPORT_PIOA
    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/
    delay_init();
    lcd_init();
    ioport_init();
    init_button_led();
    adc_setup();
    //ioport_enable_pin(PIO_PB27_IDX);
    //ioport_enable_pin(PIO_PA21_IDX);
    //ioport_enable_pin(PIO_PC30_IDX);
    //ioport_set_pin_dir(PIO_PB27_IDX,1);//1 output
    //ioport_set_pin_dir(PIO_PA21_IDX,1);
    //ioport_set_pin_dir(PIO_PC30_IDX,1);
    //lcd_string[0] = 'A';
    //sprintf(lcd_string, "HELLO"); pazi buffer overflow//strcpy(lcd_sting, "vaja 3") -> ne zagotavlja buffer overflowa


    //str2lcd("vaja 3",0);
    //lcd_driver();//prenos na LCD
    //str2lcd("x = 10",16);
    //lcd_driver();

    /********************* Main loop     ***************************/

    while(1)
    {
        //uint32_t value = get_button_state();
        //ioport_set_pin_level(D1, !(value & 0x01));//negiram ker je negirana logika na tipkah
        //ioport_set_pin_level(D2, !(value & 0x02));
        //ioport_set_pin_level(D3, !(value & 0x04));
        //ioport_set_pin_level(D4, !(value & 0x08));

        uint32_t u32_result = adc_read();
        int n = sprintf(lcd_string, "adc = %lu",u32_result);
        lcd_string[n] = ' ';
        lcd_driver();
        //str2lcd(u32_result, 16);
        if(u32_result>3276){
            ioport_set_pin_level(D4, 1);
        }
        else{
            ioport_set_pin_level(D4, 0);
        }

        if(u32_result>2457){
            ioport_set_pin_level(D3, 1);
        }
        else{
            ioport_set_pin_level(D3, 0);
        }

        if(u32_result>1638){
            ioport_set_pin_level(D2, 1);
        }
        else{
            ioport_set_pin_level(D2, 0);
        }

        if(u32_result>819){
            ioport_set_pin_level(D1, 1);
        }
        else{
            ioport_set_pin_level(D1, 0);
        }

        delay_ms(50);
    }

    /*******varnost********/
    while(1){

    }
}
//optimizacija ne zbrise volatile sprem
void cakaj(int n){
    while(n>0){
        n--;
    }
}

#ifdef __cplusplus
}
#endif
