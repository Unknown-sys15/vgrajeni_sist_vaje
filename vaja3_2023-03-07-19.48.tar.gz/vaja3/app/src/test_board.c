#include "test_board.h" // "" ali <> kje naj isce file
#include "ioport.h"
#include "adc.h"

void init_button_led(void){
    ioport_init();//vklop za paralelna vrata
    //ioport_enable_pin(PIO_PC30_IDX);
    ioport_enable_pin(T1);
    ioport_set_pin_dir(T1,IOPORT_DIR_INPUT);
    ioport_set_pin_mode(T1, IOPORT_MODE_PULLUP);
    ioport_enable_pin(T2);
    ioport_set_pin_dir(T2,IOPORT_DIR_INPUT);
    ioport_set_pin_mode(T2, IOPORT_MODE_PULLUP);
    ioport_enable_pin(T3);
    ioport_set_pin_dir(T3,IOPORT_DIR_INPUT);
    ioport_set_pin_mode(T3, IOPORT_MODE_PULLUP);
    ioport_enable_pin(T4);
    ioport_set_pin_dir(T4,IOPORT_DIR_INPUT);
    ioport_set_pin_mode(T4, IOPORT_MODE_PULLUP);

    ioport_set_pin_dir(D1,IOPORT_DIR_OUTPUT);
    ioport_enable_pin(D1);
    ioport_set_pin_dir(D2,IOPORT_DIR_OUTPUT);
    ioport_enable_pin(D2);
    ioport_set_pin_dir(D3,IOPORT_DIR_OUTPUT);
    ioport_enable_pin(D3);
    ioport_set_pin_dir(D4,IOPORT_DIR_OUTPUT);
    ioport_enable_pin(D4);
    ioport_set_pin_level(D1, 0);
    ioport_set_pin_level(D2, 0);
    ioport_set_pin_level(D3, 0);
    ioport_set_pin_level(D4, 0);


}
uint32_t get_button_state(void){//stanje tipk
    return (ioport_get_pin_level(T4)<<3) | (ioport_get_pin_level(T3)<<2) | (ioport_get_pin_level(T2)<<1) |ioport_get_pin_level(T1);//zlepis bite skupaj
}
uint32_t get_button_press(void){//enka kjer se je gumb pritisnu
    return 0;
}

void adc_setup(void){
    sysclk_enable_peripheral_clock(ID_ADC);//vklopi clock za ad converter
    adc_init(ADC, SystemCoreClock,6400000,ADC_MR_STARTUP_SUT64);//adc struktura tipa adc
    adc_configure_timing(ADC, 0, ADC_SETTLING_TIME_3, 1);
    adc_set_resolution(ADC, ADC_12_BITS);
    adc_enable_channel(ADC, ADC_CHANNEL_7);
    adc_configure_trigger(ADC, ADC_TRIG_SW, 0);

}

uint32_t adc_read(void){
    adc_start(ADC);

    while ((adc_get_status(ADC) & ADC_ISR_DRDY) != ADC_ISR_DRDY){
    }
    //adc_get_status()
    /*
        ADC_ISR:
            DRDY = 1    => adc_get_latest_value
            E0C7 = 1    => adc_get_channel_value()
    */
    return adc_get_latest_value(ADC);
}
