#ifndef TEST_BOARD_H_INCLUDED
#define TEST_BOARD_H_INCLUDED
//#include <stdint.h>
#include "asf.h"

#define D1  PIO_PC22_IDX
#define D2  PIO_PC21_IDX
#define D3  PIO_PC29_IDX
#define D4  PIO_PD7_IDX

#define T1  PIO_PC26_IDX
#define T2  PIO_PC25_IDX
#define T3  PIO_PC24_IDX
#define T4  PIO_PC23_IDX

void init_button_led(void);
uint32_t get_button_state(void);//stanje pinou
uint32_t get_button_press(void);//enka kjer se je gumb pritisnu

#endif // TEST_BOARD_H_INCLUDED

void adc_setup(void);
uint32_t adc_read(void);
