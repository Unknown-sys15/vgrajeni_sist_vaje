#include "rtos.h"
#include <math.h>
extern rtos_task_t *rtos_task_list[];  // je v loceni prevajalni enoti


uint8_t rtos_init(uint32_t slice_us){
    /**

        SysTiclk f = MCK/8
        vrne: 0 -> ce je use okej
              1 -> ce ni okej
			  
			vklopimo izjemo (exception)
			nastavimo cikle za stevec#

    **/
    uint32_t load_value = (uint32_t)((slice_us*84)/8);  // f1 -> 84*10^6/8, T2 -> 25000 *10^-6 N = T2/T1 = f1*T2


    SysTick->LOAD = load_value - 1;   // lodamo register z nekim value in on pol steje nauzdol
    SysTick->CTRL = SysTick_CTRL_TICKINT_Msk;    // mjb more bit tudi "|" vklopimo prekinitve z masko CTRL register
    SysTick->CTRL &= ~(SysTick_CTRL_CLKSOURCE_Msk);

    if(slice_us > (1<<24)){
        return 1;    // napaka ce das prevelik slice
    }



    return 0;      // init ok
}

void rtos_enable(void){
    /* Vklopi SysTick timer  */

    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;

}


void rtos_disable(void){
    /* Izklopi SysTick timer  */
    SysTick->CTRL &= ~(SysTick_CTRL_ENABLE_Msk);

}

void SysTick_Handler(){
    /**  razvrscevalnik opravil (round robin)  **/

    static uint8_t idx = 0;
    static uint32_t tick = 0;
	tick++;

    rtos_task_list[idx]->task_func();   // runamo funkcijo taska
    rtos_task_list[idx]->last_tick = tick;    // zapisesemo kolko krat se je izvedu
    idx++;

	// preverimo ce smo prisli do konca tabele
	// lahko bi tudi uint8_t rtos_num_tasks = sizeof(rtos_task_list/sizeof(rtos_task_list[0]))
    if(rtos_task_list[idx] == 0){
        idx = 0;
    }
	
	if (SCB->ICSR & SCB_ICSR_PENDSTSET_Msk) {
        // Smo zamudili, obesi se
        while(1);
    }

}
