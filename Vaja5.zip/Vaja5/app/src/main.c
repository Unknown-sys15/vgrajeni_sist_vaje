#include <asf.h>
#include <delay.h>
#include <ioport.h>
#include <string.h>
#include "test_board.h"
#include "lcd.h"
#include <tc.h>
#include "rtos_task.h"
#include "rtos.h"


#ifdef __cplusplus
extern "C" {
#endif
extern uint8_t sek;
extern uint8_t min;
extern uint8_t ure;



int main (void)
{

    /* sets the processor clock according to conf_clock.h definitions */
                                                                                                                                                                                                                                        sysclk_init();
    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/

    init_button_led();
    delay_init();
    lcd_init();

    str2lcd("Hello!", 0);



    if(rtos_init(25000) != 0){    //25ms * 4 taski = 100ms
        while(1);                //error
    }


    rtos_enable();


    /********************* Main loop     ***************************/
    while(1)
    {
        int n = sprintf(lcd_string, "%d:%d:%d", ure, min,sek);
        lcd_string[n] = ' ';

    }

    /*********************** varnost ***************************/
    while(1)
    {

    }


}










#ifdef __cplusplus
}
#endif
