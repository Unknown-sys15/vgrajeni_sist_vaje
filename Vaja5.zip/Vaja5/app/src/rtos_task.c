#include "rtos_task.h"
#include "lcd.h"
#include "test_board.h"


uint8_t sek;
uint8_t min;
uint8_t ure;


rtos_task_t task_blink = {
    .name = "blink",
    .last_tick = 0,
    .task_func = blink_driver
};

rtos_task_t task_clock = {
    .name = "clock",
    .last_tick = 0,
    .task_func = clock_driver
};

rtos_task_t task_button = {
    .name = "button",
    .last_tick = 0,
    .task_func = button_driver
};


rtos_task_t task_lcd = {
    .name = "lcd",
    .task_func = lcd_driver
};


void blink_driver(void){

    ioport_toggle_pin_level(D1);

}


void button_driver(void){

    uint32_t button_state = get_button_press();
    if(button_state & 0x01){
        ure++;
    }
    if(button_state & 0x02){
        min++;
    }
    if(button_state & 0x04){
        ure = 0;
        min = 0;
        sek = 0;
    }


}

void clock_driver(void){
	
	/*  lahko tudi samo stejes z eno spremenljivko in gledas kolko se poveca in spremenis
		sek, ure in minute
	*/ 

    static uint8_t iteracija = 0;
    if(iteracija >= 10){
        sek++;
    if(sek >= 60){
        sek = 0;
        min++;
    }
     iteracija = 0;
    }
   iteracija++;


}




// tu smo nardili array struktur rabis pointerje da lahko pol spremnijas elemente
rtos_task_t *rtos_task_list[] = {&task_blink, &task_lcd, &task_clock, &task_button, 0};     // n0 je NULL pointer to je sejfti da ves kje se konca


