#ifndef RTOS_H_INCLUDED
#define RTOS_H_INCLUDED
#include <asf.h>

/* funciton pointer  */
typedef void(*ptr_function)(void); 

/*   struktura taska      */
typedef struct {
    
	char name[20];
    uint32_t last_tick;
    uint32_t priority;         //TODO
    uint32_t interval_ms;      //TODO
    ptr_function task_func;
	
}rtos_task_t;

uint8_t  rtos_init(uint32_t slice_us);
void rtos_enable(void);
void rtos_disable(void);



#endif // RTOS_H_INCLUDED
