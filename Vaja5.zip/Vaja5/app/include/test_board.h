#ifndef TEST_BOARD_H_INCLUDED
#define TEST_BOARD_H_INCLUDED

//#include <stdint.h>
#include "asf.h"

typedef struct{

    Pio *port;
    uint32_t msk;
    uint32_t idx;
}gpio_pin_t;

#define T1 {PIOC, PIO_PC26, PIO_PC26_IDX}
#define T2 {PIOC, PIO_PC25, PIO_PC25_IDX}
#define T3 {PIOC, PIO_PC24, PIO_PC24_IDX}
#define T4 {PIOC, PIO_PC23, PIO_PC23_IDX}


#define D1 PIO_PC22_IDX
#define D2 PIO_PC21_IDX
#define D3 PIO_PC29_IDX
#define D4 PIO_PD7_IDX

#define G1 PIO_PC26_IDX
#define G2 PIO_PC25_IDX
#define G3 PIO_PC24_IDX
#define G4 PIO_PC23_IDX
/*
#define D2 PIO_PC22_IDX
#define D3 PIO_PC22_IDX
#define D4 PIO_PC22_IDX

#define G1 PIO_PC22_IDX
#define G2 PIO_PC22_IDX
#define G3 PIO_PC22_IDX
#define G4 PIO_PC22_IDX
*/


void init_button_led(void);
uint32_t get_button_state(void);
uint32_t get_button_press(void);

void adc_setup(void);
uint32_t adc_read(void);

extern gpio_pin_t pini[];

#endif // TEST_BOARD_H_INCLUDED
