#ifndef RTOS_TASK_H_INCLUDED
#define RTOS_TASK_H_INCLUDED
#include "rtos.h"

void blink_driver(void);
void clock_driver(void);
void button_driver(void);



#endif // RTOS_TASK_H_INCLUDED
