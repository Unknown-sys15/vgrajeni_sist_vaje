#ifndef RTOS_H_INCLUDED
#define RTOS_H_INCLUDED

#include <asf.h>
typedef void(*ptr_function)(void);//KAZALEC NA FUNKCIJO

typedef struct{
    char name[20];
    uint32_t last_tick;
    uint32_t priority; //TODO
    uint32_t interval; //TODO
    ptr_function task_function;
}rtos_task_t;

uint32_t rtos_init(uint32_t slice_us);
void rtos_enable(void);
void rtos_disable(void);
#endif // RTOS_H_INCLUDED

