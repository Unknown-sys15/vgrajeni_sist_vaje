#ifndef RTOS_TASKS_H_INCLUDED
#define RTOS_TASKS_H_INCLUDED

#include <rtos.h>
#include <lcd.h>
#include "fifo.h"

#define KEYS_FIFO_SIZE 10   // prostora je dejansko 9 Byte-ov
extern fifo_t keys_fifo;


void blink_driver(void);
void led_driver(void);
void txt_driver(void);
void btn_driver(void);
void dummy_driver(void);
#endif // RTOS_TASKS_H_INCLUDED
