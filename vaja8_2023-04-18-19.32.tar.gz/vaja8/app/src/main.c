#include <asf.h>
#include <delay.h>
#include <ioport.h>
#include <string.h>
#include "test_board.h"
#include "lcd.h"
#include <tc.h>
#include <rtos.h>
#include <rtos_tasks.h>
#include <fifo.h>
#include <math.h>


#ifdef __cplusplus
extern "C" {
#endif

void timer1_init(void);

#define NS 5
int sinus[NS];
int triang[NS];
int *izbranSignal = sinus;//pointer na signal
int f = 10;//frekvenca

int premik=1;
int indexDACC=0;

void TC0_Handler(void){
    ioport_toggle_pin_level(D1);
    if(DACC_ISR_TXRDY & dacc_get_interrupt_status(DACC))
    {
        if(( void * )izbranSignal == ( void * )&sinus){
            dacc_write_conversion_data(DACC, sinus[indexDACC]);
        }
        else{
            dacc_write_conversion_data(DACC, triang[indexDACC]);
        }
        if(indexDACC==4){
                premik=0;
        }
        else if(indexDACC==0){
            premik=1;
        }
        if(premik==1){
                indexDACC++;
        }
        else{indexDACC--;}
    }

    tc_get_status(TC0,0);//reset flag
}



int main (void)
{

    /****DAC SETUP****//* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();
    sysclk_enable_peripheral_clock(ID_DACC);
    dacc_reset(DACC);
    dacc_set_transfer_mode(DACC, DACC_MR_WORD_HALF);
    dacc_set_timing(DACC, 0x08, 0, 0x10); /* refresh, max speed, startup time */
    dacc_set_channel_selection(DACC, 1);
    dacc_enable_channel(DACC, 1);
    /****TIMER SETUP****/
    NVIC_EnableIRQ(TC0_IRQn); //pogledas v sam3x8e.h
    sysclk_enable_peripheral_clock(ID_TC0);
    tc_init(TC0,0,TC_CMR_WAVE|TC_CMR_TCCLKS_TIMER_CLOCK3|TC_CMR_WAVSEL_UP_RC);
    tc_enable_interrupt(TC0, 0,TC_IER_CPCS);
    tc_start(TC0,0);//START TIMER!!!!
    uint32_t vrednost = (uint32_t)(84*1000000/(32*2*(NS-1)*f));
    tc_write_rc(TC0,0,vrednost);//v interuptu togglaj ta tc_write                                                                                                                                                                                            sysclk_init();

    adc_setup();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/

    init_button_led();
    delay_init();
    lcd_init();

    /********************* Main loop     ***************************/
    for(int i=0;i<NS;i++){
        triang[i] = 4095 * i / (NS-1);
        sinus[i] = 4095 * (sin( 3.14 / 2 * (NS-1 + 2*i) / (NS-1) ) + 1) / 2;
    }
    uint32_t button_state;
    while(1)
    {
        //////////////UPDATE LCD///////////////////////
        uint32_t n = sprintf(lcd_string, "f=%d Hz", f);
        lcd_string[n] = ' ';
        if(( void * )izbranSignal == ( void * )&sinus){
            n = sprintf(lcd_string+16, "Signal= sinus");
        }
        else{
            n = sprintf(lcd_string+16, "Signal= trikot");
        }
        lcd_string[n+16] = ' ';
        lcd_driver();
        ////////////////////////////////////////////////////
        //////////////VREDNOST STEVCA////////////////////////
        vrednost = (uint32_t)(84*1000000/(32*2*(NS-1)*f));
        tc_write_rc(TC0,0,vrednost);//v interuptu togglaj ta tc_write
        ////////////////////////////////////////////////////
        int f_prej = f;
        uint32_t u32_result = adc_read();
        f = u32_result*30/4095;
        if(f!=f_prej){
            tc_start(TC0,0);//treba se enx startat ker cene ne generira signala
        }
        //////////////OBLIKA SIGNALA///////////////////////
        button_state = get_button_press();//fora lih da toggla
        if(button_state & 0x01){//T4
            izbranSignal = sinus;
        }
        if(button_state & 0x02){//T3
            izbranSignal = triang;
        }
        ////////////////////////////////////////////////////

    }

    /*********************** varnost ***************************/
    while(1)
    {

    }


}


#ifdef __cplusplus
}
#endif
