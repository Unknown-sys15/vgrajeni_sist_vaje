#include "test_board.h"
#include "ioport.h"
#include <delay.h>

uint32_t result = 0;


void init_button_led(void){
    ioport_init();

    ioport_enable_pin(G1);
    ioport_set_pin_dir(G1, IOPORT_DIR_INPUT);
    ioport_set_pin_mode(G1, IOPORT_MODE_PULLUP | IOPORT_MODE_DEBOUNCE);

    ioport_enable_pin(G2);
    ioport_set_pin_dir(G2, IOPORT_DIR_INPUT);
    ioport_set_pin_mode(G2, IOPORT_MODE_PULLUP | IOPORT_MODE_DEBOUNCE);

    ioport_enable_pin(G3);
    ioport_set_pin_dir(G3, IOPORT_DIR_INPUT);
    ioport_set_pin_mode(G3, IOPORT_MODE_PULLUP | IOPORT_MODE_DEBOUNCE);

    ioport_enable_pin(G4);
    ioport_set_pin_dir(G4, IOPORT_DIR_INPUT);
    ioport_set_pin_mode(G4, IOPORT_MODE_PULLUP | IOPORT_MODE_DEBOUNCE);

    pio_set_debounce_filter(PIOC, 1 << 26 | 1 << 25 | 1 << 24 | 1 << 23, 100);

    ioport_enable_pin(D1);
    ioport_set_pin_dir(D1, IOPORT_DIR_OUTPUT);

    ioport_enable_pin(D2);
    ioport_set_pin_dir(D2, IOPORT_DIR_OUTPUT);

    ioport_enable_pin(D3);
    ioport_set_pin_dir(D3, IOPORT_DIR_OUTPUT);

    ioport_enable_pin(D4);
    ioport_set_pin_dir(D4, IOPORT_DIR_OUTPUT);


}


uint32_t get_button_state(void){
    uint32_t out = 0;
    /*
        Vrne stanje tipk (1 => pritisnjena)
    */


    out |= !ioport_get_pin_level(G1);
    out |= !ioport_get_pin_level(G2)<<1;
    out |= !ioport_get_pin_level(G3)<<2;
    out |= !ioport_get_pin_level(G4)<<3;

    return out;
}


uint32_t get_button_press(void){
    uint32_t out = 0;

    /*
        Vrne enko ob frontah:
            bit0 => 1, ce je padajoca fronta na G1
            bit0 => 1, ce je padajoca fronta na G2
    */

    static uint32_t tipke_prej = 0;


    uint32_t tipke_zdaj = get_button_state();           // static pomeni da se ne povozi

    out = ~tipke_prej &  tipke_zdaj;


    // to mogoce ne deluje
    tipke_prej = tipke_zdaj;


    return out;
}

void adc_setup(void){
    sysclk_enable_peripheral_clock(ID_ADC); // vklopi clock za ADC
    adc_init(ADC, SystemCoreClock, 6400000, ADC_MR_STARTUP_SUT64);
    adc_configure_timing(ADC, 0,ADC_SETTLING_TIME_3, 1);
    adc_set_resolution(ADC, ADC_12_BITS);
    adc_configure_trigger(ADC, ADC_TRIG_SW, 0);
    adc_enable_channel(ADC, ADC_CHANNEL_7);

}

uint32_t adc_read(void){

    /**
        ADC_IST:
            DRDY = 1    => adc_get_latest_value(const Adc *p_adc);
            EOC7 = 1    => adc_get_channel_value(const Adc *p_adc, const enum adc_channel_num_t adc_ch);


     **/


    adc_start(ADC);

     if (adc_get_status(ADC) & ADC_ISR_DRDY){
           while(ADC_ISR_DRDY == 0){}
            result = adc_get_latest_value(ADC);
       }

    return result;





}


