#include <asf.h>
#include <delay.h>
#include <ioport.h>
#include <string.h>
#include "test_board.h"
#include "lcd.h"
#include <tc.h>

#ifdef __cplusplus
extern "C" {
#endif

#define CYCLES_1 2625100
int cycles_on, cycles_off;


void timer1_init(void);





uint32_t n_off ;
uint32_t n_on ;

int main (void)
{

    /* sets the processor clock according to conf_clock.h definitions */
                                                                                                                                                                                                    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/

    init_button_led();
    delay_init();
    lcd_init();


    sysclk_enable_peripheral_clock(ID_TC0);
    tc_init(TC0, 0, TC_CMR_TCCLKS_TIMER_CLOCK3 | TC_CMR_WAVE | TC_CMR_WAVSEL_UP_RC);
    tc_enable_interrupt(TC0, 0, TC_IER_CPCS);
    NVIC_EnableIRQ(TC0_IRQn);
    tc_start(TC0, 0);





    uint32_t button_state;
    uint32_t f = 1;  // Hz
    uint32_t dc = 25;    // %

    uint32_t toff_us = 1000000/f*(100-dc)/100;
    uint32_t ton_us = 1000000/f*dc/100;
    n_on = ton_us*84/32;
    n_off = toff_us*84/32;
    tc_write_rc(TC0,0,n_off);

    /********************* Main loop     ***************************/
    while(1)
    {


    button_state = get_button_press();
    if(button_state & 0x01){
        f++;
    }
    else if(button_state & 0x02){
        f--;
    }
    else if(button_state & 0x04){
        dc++;
    }
    else if(button_state & 0x08){
        dc--;
    }

    toff_us = 1000000/f*(100-dc)/100;
    ton_us = 1000000/f*dc/100;
    n_on = ton_us*84/32;
    n_off = toff_us*84/32;

    int n = sprintf(lcd_string, "Frekvenca = %lu", f);
        lcd_string[n] = ' ';
    int m = sprintf(lcd_string+16, "Duty = %lu", dc);
        lcd_string[16+m] = ' ';
    lcd_driver();

    }

    /*********************** varnost ***************************/
    while(1)
    {

    }


}



void TC0_Handler(void){
    static uint8_t stanje = 0;
    if(stanje==0){
        ioport_set_pin_level(D1,1);
        tc_write_rc(TC0,0,n_on);
    }
    else{
        ioport_set_pin_level(D1,0);
        tc_write_rc(TC0,0,n_off);
    }
    stanje = 1-stanje;

    tc_get_status(TC0, 0);
}



#ifdef __cplusplus
}
#endif
