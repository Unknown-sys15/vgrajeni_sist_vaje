#include <rtos_tasks.h>
#include <test_board.h>
extern int sek,min;

/********************************/
rtos_task_t task_blink = {
    .name = "blink",
    .last_tick = 0,
    .task_function = blink_driver
};

void blink_driver(void){
    static uint32_t count=0;
    count++;

    if(count ==1){
        count=0;
        ioport_toggle_pin_level(D1);
    }
}
/********************************/
rtos_task_t task_lcd={
    .name = "lcd",
    .task_function = lcd_driver
};

/********************************/
rtos_task_t task_clock={
    .name = "count",
    .task_function = clock_driver
};
void clock_driver(void){
    sek++;
    if(sek>=60){
        min++;
        sek=0;
    }
}
/********************************/
rtos_task_t task_buttons={
    .name = "buttons",
    .task_function = button_driver
};
void button_driver(void){
    uint32_t button_state = get_button_press();

    if(button_state & 0x01){
            sek++;
    }
    if(button_state & 0x02){
            sek--;
    }
    if(button_state & 0x04){
            sek=0;
            min=0;
    }
}
/********************************/
rtos_task_t *rtos_task_list[]={&task_blink,&task_lcd,&task_clock,&task_buttons, 0};//
