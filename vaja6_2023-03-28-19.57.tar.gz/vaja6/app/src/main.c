#include <asf.h>
#include <delay.h>
#include <ioport.h>
#include <string.h>
#include "test_board.h"
#include "lcd.h"
#include <tc.h>
#include <rtos.h>
#include <rtos_tasks.h>


#ifdef __cplusplus
extern "C" {
#endif

#define CYCLES_1 2625100
int cycles_on, cycles_off;
int sek=0;
int min=0;

void timer1_init(void);




//uint32_t click=0;
uint32_t n_off ;
uint32_t n_on ;

int main (void)
{

    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();

                                                                                                                                                                                                    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/

    init_button_led();
    delay_init();
    lcd_init();

    if (rtos_init(250000) != 0){
        while(1); //err
    }

    rtos_enable();




    /********************* Main loop     ***************************/
    while(1)
    {
        int n = sprintf(lcd_string, "00:0%d:%d",min,sek);
        lcd_string[n]=' ';

    }

    /*********************** varnost ***************************/
    while(1)
    {

    }


}




#ifdef __cplusplus
}
#endif
