#include <rtos.h>
#include <math.h>

extern rtos_task_t *rtos_task_list[];

 uint32_t rtos_init(uint32_t slice_us){
    /**
    sysTick f = MCK/8
    vrne 0 ce je okej
    vrne 1 ce je napaka
    */
    SysTick -> CTRL = SysTick_CTRL_TICKINT_Msk; //vklopi exception   postavi TICINT na 1 |
    SysTick -> CTRL &= ~SysTick_CTRL_CLKSOURCE_Msk; // mck/8    postavi CLKSOURCe na 0

    //if(poglej velicino stevca)
    uint32_t load_value = (uint32_t)(slice_us*84/8);
    if(load_value>= (1<<24) ){
        return 1;
    }
    SysTick -> LOAD = load_value;/**zracunaj pravo vr**///43700

    //SysTick -> CTRL &= ~SysTick_CTRL_CLKSOURCE_Msk;

    return 0;
 }


 void rtos_enable(void){
    /**vklopi sysTick timer**/
    SysTick -> CTRL |= SysTick_CTRL_ENABLE_Msk;
 }

 void rtos_disable(void){
    /**izklopi sysTick timer**/
    SysTick -> CTRL &= ~SysTick_CTRL_ENABLE_Msk;
 }

 void SysTick_Handler(void){
    /**razvrščevalnik opravil (round robin)**/
    static uint32_t idx = 0;
    static uint32_t tick = 0;
    tick++;

    rtos_task_list[idx]->task_function();
    rtos_task_list[idx]->last_tick = tick;
    idx++;

    if(rtos_task_list[idx]== 0){
        idx=0;
    }

 }
