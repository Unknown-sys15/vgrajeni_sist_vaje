#ifndef RTOS_TASKS_H_INCLUDED
#define RTOS_TASKS_H_INCLUDED

#include <rtos.h>
#include <lcd.h>
void blink_driver(void);

void clock_driver(void);
void button_driver(void);
#endif // RTOS_TASKS_H_INCLUDED
